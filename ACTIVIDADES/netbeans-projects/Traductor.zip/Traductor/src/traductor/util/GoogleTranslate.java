package traductor.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.unbescape.html.HtmlEscape;
/**
 *
 * statickidz@gmail.com
 * https://statickidz.com
 */
public class GoogleTranslate {

    private final String TRANSLATION_URL = "https://translate.google.com/";

    private String source;
    private String target;
    private String text;
    private String result;

    public String translate(String text, String source, String target) {
        this.source = source;
        this.target = target;
        this.text = text;
        this.result = "";

        requestTranslation();
        cleanTranslation();

        return this.result;
    }

    private void requestTranslation() {

        try {

            URL url = new URL(TRANSLATION_URL);
            HttpURLConnection httpCon = (HttpURLConnection) url.openConnection();
            httpCon.addRequestProperty("User-Agent",
                    "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0)");
            httpCon.setDoOutput(true);
            httpCon.setRequestMethod("POST");
            OutputStreamWriter writer = new OutputStreamWriter(httpCon.getOutputStream(), "UTF-8");
            writer.write(
                    "sl=" + this.source +
                            "&tl=" + this.target +
                            "&hl=" + this.source +
                            "&text=" + this.text +
                            "&ie=UTF-8&js=n&prev=_t&file=&edit-text="
            );
            writer.flush();

            String line;
            BufferedReader reader;
            reader = new BufferedReader(new InputStreamReader(httpCon.getInputStream(), "UTF-8"));
            while ((line = reader.readLine()) != null) {
                this.result = getStringBetween("onmouseout=\"this.style.backgroundColor='#fff'\">", "</span>", line);
            }

            writer.close();

        } catch (MalformedURLException e) {
            e.getMessage();
        } catch (IOException e) {
            e.getMessage();
        }
    }


    private void cleanTranslation() {
        this.result = HtmlEscape.unescapeHtml(this.result);
        this.result = this.result.replace("<br>", " ");
        this.result = this.result.replace("  ", " ");
    }

    private String getStringBetween(String start, String end, String text) {
        String response = "";
        Pattern p = Pattern.compile(Pattern.quote(start) + "(.*?)" + Pattern.quote(end));
        Matcher m = p.matcher(text);
        while (m.find()) {
            response += m.group(1);
        }
        return response;
    }

}