# Trackio
JavaFX audio player with folder playlist.

![Alt "Trackio Audio Player"](http://img.imgur.com/rECNn8j.png "Trackio Audio Player")

Based on aurous.me UI.

[https://statickidz.com](https://statickidz.com)
