# -*- encoding: utf-8 -*-
{
    "name": "Mi libro", 
    "author": "Pepe", 
    "description": "Ejemplo",
    "version": "1.4", 
    "depends": [],
    "data" : ["milibro_view.xml"],
    "update_xml": [], 
    "category": "Try/Others", 
    "license" :"Other OSI approved licence",
    "active": False, 
    "installable": True
}