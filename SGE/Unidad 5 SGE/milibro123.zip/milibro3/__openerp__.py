# -*- encoding: utf-8 -*-
{
    "name": "Herencia de vistas", 
    "author": "Pepe", 
    "version": "1.3", 
    "depends": ["base","milibro"], 
    "init_xml": [],
    "update_xml": ["milibro3_view.xml"], 
    "category": "Try/Others", 
    "active": True, 
    "installable": True
}

