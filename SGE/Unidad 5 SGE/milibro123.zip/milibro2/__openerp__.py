# -*- encoding: utf-8 -*-
{
    "name" : "Módulo de Prueba", 
    "author": "Pepe", 
    "version": "1.4", 
    "depends": ["base","milibro"], 
    "init_xml": [],
    "update_xml": ["milibro2_view.xml"], 
    "category": "Try/Others", 
    "active": True, 
    "installable": True
}
